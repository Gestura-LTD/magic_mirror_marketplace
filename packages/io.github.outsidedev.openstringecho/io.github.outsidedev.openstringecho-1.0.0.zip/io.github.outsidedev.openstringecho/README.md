# Open String Echo

A tiny game for the MagicMirror_MusicLearningCompanion. The mirror shows one open string (G, D, A, E).
Play it; the ring turns green while you are within 15 cents. Hold it in tune for one second and the next
string comes. All four strings = one round; the round's time is the one score.

Art: none (text and shapes only). Font: the mirror's default. Code: MIT.
