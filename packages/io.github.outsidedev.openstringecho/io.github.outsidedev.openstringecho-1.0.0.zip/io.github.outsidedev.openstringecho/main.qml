// Open String Echo -- a tiny MagicMirror_MusicLearningCompanion game (sdk 1).
// The mirror shows one open string (G3, D4, A4, E5). Play it; the ring turns green while the
// note is within 15 cents, and after 1 s held in tune the next string comes. Four strings = one round.
// Rules kept: no score on screen while playing; unsure reading = pause (never a miss); short round.
import QtQuick

Item {
    id: game
    readonly property var d: mirror.d
    readonly property var strings: [
        { name: "G", note: "G3", hz: 196.00 },
        { name: "D", note: "D4", hz: 293.66 },
        { name: "A", note: "A4", hz: 440.00 },
        { name: "E", note: "E5", hz: 659.26 }
    ]
    readonly property real holdS: 1.0
    readonly property real bandCents: 15
    property int idx: 0
    property real heldSince: -1
    property bool inTune: false
    property bool done: false
    property real roundStart: -1
    property string hint: "play the open string"

    function target() { return strings[idx] }

    function newRound() {
        idx = 0; done = false; heldSince = -1; inTune = false; roundStart = -1
        hint = "play the open string"
        mirror.setTarget(target().hz)
    }

    Component.onCompleted: newRound()

    onDChanged: {
        if (done) return
        var p = d.pitch || {}, sig = d.signal || {}
        // pause, never punish: no clear note -> no judgement at all
        if (!sig.sounding || typeof p.cents !== "number" || !p.note || (p.conf !== undefined && p.conf < 0.5)) {
            heldSince = -1; inTune = false; hint = "play the open string"; return
        }
        if (roundStart < 0) roundStart = mirror.now()
        var t = target()
        if (p.note !== t.note) {
            heldSince = -1; inTune = false
            hint = "that is " + p.note + " - try the " + t.name + " string"
            return
        }
        if (Math.abs(p.cents) > bandCents) {
            heldSince = -1; inTune = false
            hint = p.cents > 0 ? "a little high" : "a little low"
            return
        }
        inTune = true
        hint = "hold it"
        if (heldSince < 0) heldSince = mirror.now()
        if (mirror.now() - heldSince >= holdS) {
            heldSince = -1; inTune = false
            if (idx < strings.length - 1) {
                idx++
                mirror.setTarget(target().hz)
                hint = "next string"
            } else {
                done = true
                var secs = mirror.now() - roundStart
                // one figure carried forward: faster = better, compared with yourself only
                var v = Math.max(0, Math.min(1, 1 - (secs - 8) / 52))
                mirror.score("openstrings", v, "G D A E in " + secs.toFixed(1) + " s")
                hint = "all four strings!"
            }
        }
    }

    Rectangle { anchors.fill: parent; color: "#14181C" }

    // the four strings, the current one bright
    Row {
        id: row
        anchors.horizontalCenter: parent.horizontalCenter
        anchors.top: parent.top; anchors.topMargin: parent.height * 0.08
        spacing: parent.width * 0.06
        Repeater {
            model: game.strings
            Text {
                required property var modelData
                required property int index
                text: modelData.name
                font.pixelSize: game.width * 0.09
                color: index === game.idx && !game.done ? "#E6EAED" : (index < game.idx || game.done ? "#37D2B4" : "#3A4248")
            }
        }
    }

    Rectangle {
        id: ring
        anchors.centerIn: parent
        width: Math.min(parent.width, parent.height) * 0.6; height: width; radius: width / 2
        color: "transparent"; border.width: Math.max(4, width * 0.02)
        border.color: game.inTune || game.done ? "#37D2B4" : "#3A4248"
        Behavior on border.color { ColorAnimation { duration: 120 } }
        Text {
            anchors.centerIn: parent
            text: game.done ? "★" : game.target().name
            color: game.inTune || game.done ? "#37D2B4" : "#E6EAED"
            font.pixelSize: parent.width * 0.45
        }
    }

    Text {
        anchors.top: ring.bottom; anchors.topMargin: parent.height * 0.04
        anchors.horizontalCenter: parent.horizontalCenter
        text: game.hint
        color: "#E6EAED"; font.pixelSize: game.width * 0.055
    }

    Text {
        visible: game.done
        anchors.bottom: parent.bottom; anchors.bottomMargin: parent.height * 0.08
        anchors.horizontalCenter: parent.horizontalCenter
        text: "tap to play again"
        color: "#8B959C"; font.pixelSize: game.width * 0.045
    }
    MouseArea { anchors.fill: parent; enabled: game.done; onClicked: game.newRound() }
}
